package com.cg.proapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.proapp.bean.Product;
import com.cg.proapp.dao.ProductDao;
@Service
public class ProductServiceImpl implements ProductService {
@Autowired
ProductDao productDao;

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return productDao.findAll();
	}

	@Override
	public Product getProductById(String id) {
		// TODO Auto-generated method stub
		return productDao.findById(id).get();
	}

	@Override
	public void updateProduct(Product pro) {
		// TODO Auto-generated method stub
		productDao.save(pro);
	}

	@Override
	public void addProduct(Product pro) {
		// TODO Auto-generated method stub
		productDao.save(pro);
		
	}

	@Override
	public void deleteProduct(String id) {
		// TODO Auto-generated method stub
		 productDao.deleteById(id);
	}

	

}
